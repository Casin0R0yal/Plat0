package Monopoly;

public enum type {
    PARC,
    JAIL,
    COMMISSION,
    LUCK,

    TAXES,
    START,

    TRAINSTATIONS,
    COMPANIES,
    
    LAND,
}